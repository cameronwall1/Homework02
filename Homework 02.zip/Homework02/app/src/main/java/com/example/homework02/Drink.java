package com.example.homework02;

import java.io.Serializable;
import java.util.Date;

public class Drink implements Serializable {
    int drinkSize;
    int alcoholLevel;
    String currentDate;

    public Drink () {};

    public Drink (int drinkSize, int alcoholLevel,String date) {
        this.drinkSize = drinkSize;
        this.alcoholLevel = alcoholLevel;
        this.currentDate = date;
    }



}
