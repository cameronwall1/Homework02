package com.example.homework02;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class AddDrink extends AppCompatActivity {
    static int drinkSize;
    static boolean sizeChanged = false;
    final static public String DRINK_KEY = "Drink";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_drink);
        SeekBar seekBar = findViewById(R.id.seekBar);
        TextView progressTextView = findViewById(R.id.progressTextView);
        Button cancelButton = findViewById(R.id.cancelButton);
        Button addDrinkButton = findViewById(R.id.addDrinkButton1);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.oneOZradio) {
                    drinkSize = 1;
                    sizeChanged = true;
                } else if (i == R.id.fiveOZradio) {
                    drinkSize = 5;
                    sizeChanged = true;
                } else {
                    drinkSize = 12;
                    sizeChanged = true;
                }
            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                progressTextView.setText(String.valueOf(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        addDrinkButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                if ((Integer.parseInt(progressTextView.getText().toString()) > 0) && sizeChanged == true ) {
//                    Log.d("DrinkValue","Progress Made: " + Integer.parseInt(progressTextView.getText().toString()));
//                    Log.d("DrinkValue","Drink Size: " + drinkSize);
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm a");
                    LocalDateTime now = LocalDateTime.now();
                    Drink drink = new Drink(drinkSize,Integer.parseInt(progressTextView.getText().toString()),dtf.format(now));
                    Log.d("DrinkValue","Date : " + drink.currentDate);
                    Log.d("DrinkValue","Progress Made From Drink Class: " + drink.alcoholLevel);
                    Log.d("DrinkValue","Drink Size From Drink Class: " + drink.drinkSize);
                    Intent drinkIntent = new Intent(getApplicationContext(),MainActivity.class);
                    drinkIntent.putExtra(DRINK_KEY,drink);
                    setResult(RESULT_OK,drinkIntent);
                    finish();
                } else if (Integer.parseInt(progressTextView.getText().toString()) == 0) {
                    Toast.makeText(getApplicationContext(),"Adjust Alcohol Level",Toast.LENGTH_SHORT).show();
                } else if (!sizeChanged) {
                    Toast.makeText(getApplicationContext(),"Set Drink Size",Toast.LENGTH_SHORT).show();
                }
            }
        });



        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}