package com.example.homework02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewDrinks extends AppCompatActivity {
    ArrayList <Drink> listOfDrinks = new ArrayList<>();
    final static public String DRINK_LIST = "Drink_List";
    static int display = 1;
    static int x = 0;
    static int numberOfDrinks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_drinks);
        ImageView backwardButton = findViewById(R.id.backwardDrinkButton);
        ImageView trashCanButton = findViewById(R.id.trashcanButton);
        ImageView forwardButton = findViewById(R.id.forwardDrinkButton);
        Button cancelButton3 = findViewById(R.id.cancelButton3);
        TextView currentDrinkNumber = findViewById(R.id.currentDrinkNumber);
        TextView totalDrinkNumber = findViewById(R.id.totalNumberOfDrinks1);
        TextView alcoholLevelID = findViewById(R.id.alcoholLevelid2);
        TextView dateAddedID2 = findViewById(R.id.dateAddedId2);
        TextView drinkSizeID2 = findViewById(R.id.drinkSizeID2);

        if (getIntent() != null && getIntent().getExtras() != null && getIntent().hasExtra(MainActivity.DRINK_LIST)) {
            ArrayList <Drink> drinkList = (ArrayList) getIntent().getSerializableExtra(MainActivity.DRINK_LIST);
            Log.d("UserInformation33","First Drink Element - Drink Size: " + drinkList.get(0).drinkSize);
            Log.d("UserInformation33","First Drink Element - Alcohol Level: " + drinkList.get(0).alcoholLevel);
            numberOfDrinks = drinkList.size();
            totalDrinkNumber.setText(String.valueOf(numberOfDrinks));
            currentDrinkNumber.setText(String.valueOf(1));
            alcoholLevelID.setText(String.valueOf(drinkList.get(0).alcoholLevel) + "% Alcohol");
            drinkSizeID2.setText(String.valueOf(drinkList.get(0).drinkSize) + "oz");
            dateAddedID2.setText("Added: " + drinkList.get(0).currentDate);

            cancelButton3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });

            backwardButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (x != 0) {
                        x--;
                        display--;
                        Log.d("UserInformation33","First Drink Element - Drink Size: " + drinkList.get(x).drinkSize);
                        Log.d("UserInformation33","First Drink Element - Alcohol Level: " + drinkList.get(x).alcoholLevel);
                        currentDrinkNumber.setText(String.valueOf(display));
                        alcoholLevelID.setText(String.valueOf(drinkList.get(x).alcoholLevel) + "% Alcohol");
                        drinkSizeID2.setText(String.valueOf(drinkList.get(x).drinkSize) + "oz");
                        dateAddedID2.setText("Added: " + drinkList.get(x).currentDate);
                    }
                }
            });

            trashCanButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (drinkList.size() == 1) {
//                        Toast.makeText(getApplicationContext(),"Only Drink in Cue.. Cannot Remove",Toast.LENGTH_SHORT).show();
                        drinkList.remove(x);
                        finish();
                    } else {
                        drinkList.remove(x);
                        totalDrinkNumber.setText(String.valueOf((numberOfDrinks -= 1)));
                    }

                    if (x == 0) {
                        Log.d("UserInformation33","First Drink Element - Drink Size: " + drinkList.get(x).drinkSize);
                        Log.d("UserInformation33","First Drink Element - Alcohol Level: " + drinkList.get(x).alcoholLevel);
                        currentDrinkNumber.setText(String.valueOf(display));
                        alcoholLevelID.setText(String.valueOf(drinkList.get(x).alcoholLevel) + "% Alcohol");
                        drinkSizeID2.setText(String.valueOf(drinkList.get(x).drinkSize) + "oz");
                        dateAddedID2.setText("Added: " + drinkList.get(x).currentDate);
                    } else {
                        x--;
                        display--;
                        Log.d("UserInformation33","First Drink Element - Drink Size: " + drinkList.get(x).drinkSize);
                        Log.d("UserInformation33","First Drink Element - Alcohol Level: " + drinkList.get(x).alcoholLevel);
                        currentDrinkNumber.setText(String.valueOf(display));
                        alcoholLevelID.setText(String.valueOf(drinkList.get(x).alcoholLevel) + "% Alcohol");
                        drinkSizeID2.setText(String.valueOf(drinkList.get(x).drinkSize) + "oz");
                        dateAddedID2.setText("Added: " + drinkList.get(x).currentDate);
                    }
                }
            });

            forwardButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (x != (drinkList.size() - 1)) {
                        x++;
                        display++;
                        Log.d("UserInformation33","First Drink Element - Drink Size: " + drinkList.get(x).drinkSize);
                        Log.d("UserInformation33","First Drink Element - Alcohol Level: " + drinkList.get(x).alcoholLevel);
                        currentDrinkNumber.setText(String.valueOf(display));
                        alcoholLevelID.setText(String.valueOf(drinkList.get(x).alcoholLevel) + "% Alcohol");
                        drinkSizeID2.setText(String.valueOf(drinkList.get(x).drinkSize) + "oz");
                        dateAddedID2.setText("Added: " + drinkList.get(x).currentDate);
                    }
                }
            });
        }
    }
}