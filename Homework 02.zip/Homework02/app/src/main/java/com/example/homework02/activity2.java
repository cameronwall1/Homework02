package com.example.homework02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class activity2 extends AppCompatActivity {
    final static public String WEIGHT_KEY = "Weight";
    final static public String GENDER_KEY = "Gender";
    static float weight;
    static String gender;
    static boolean genderSelected = false;
    static boolean weightEntered = false;
    static String proceed;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        RadioGroup radio = findViewById(R.id.radioGroup2);
        Button setButton = findViewById(R.id.weightButton);
        EditText weightText = findViewById(R.id.enterWeightEditText);
        Button cancelButton = findViewById(R.id.cancelButton2);

        Log.d("finalCheck", "Gender Selected: " + genderSelected);

        radio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.femaleRadioButton) {
                    gender = "Female";
                    genderSelected = true;
                    Log.d("finalCheck","Gender: " + gender);
                    Log.d("finalCheck","Gender Selected: " + genderSelected);
                } else {
                    gender = "Male";
                    genderSelected = true;
                    Log.d("finalCheck","Gender: " + gender);
                    Log.d("finalCheck","Gender Selected: " + genderSelected);
                }
            }
        });
        setButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Check","Button has been pressed - 1");
                if (weightText.getText().toString().isEmpty()) {
                    Log.d("Check","Weight button was pressed - 2");
                    Log.d("Check","Weight entered: " + weightEntered);
                    Toast.makeText(getApplicationContext(),"Enter Weight",Toast.LENGTH_SHORT).show();
                } else {
                    weight = Float.valueOf(weightText.getText().toString());
                    if (weight <= 0) {
                        Toast.makeText(getApplicationContext(),"Enter Weight",Toast.LENGTH_SHORT).show();
                    }
                    weightEntered = true;
                    Log.d("Check","Weight entered: " + weight);

                }

                if (genderSelected && weightEntered) {
                    Intent intent2 = new Intent(activity2.this,MainActivity.class);
                    intent2.putExtra(WEIGHT_KEY,String.valueOf(weight));
                    intent2.putExtra(GENDER_KEY,gender);
                    Log.d("Put_Extra","Weight has been entered: " + weight);
                    Log.d("Put_Extra","Gender has been entered: " + gender);
                    setResult(RESULT_OK,intent2);
                    proceed = "continue";
                    finish();
//                    startActivity(intent2);

                }
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}