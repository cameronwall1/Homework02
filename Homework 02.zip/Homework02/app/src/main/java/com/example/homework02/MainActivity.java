package com.example.homework02;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList <Drink> drinks = new ArrayList();
    final static public String WEIGHT_KEY = "Weight";
    final static public String GENDER_KEY = "Gender";
    final static public String DRINK_KEY = "Drink";
    final static public String DRINK_LIST = "Drink_List";
    Button weightButton;
    TextView weightText;
    TextView drinkText;
    Button viewDrinkButton;
    Button addDrinkButton;
    TextView numberOfDrinksText;
    Button resetButton;

    ActivityResultLauncher <Intent> startForResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            Log.d("Result","Shit got in if statement 1");
            if (result != null && result.getResultCode() == RESULT_OK) {
                Log.d("Result","Shit got in if statement");
                if (result.getData() != null && result.getData().getStringExtra(activity2.GENDER_KEY) != null && result.getData().getStringExtra(activity2.WEIGHT_KEY) != null) {
                    weightText.setText(result.getData().getStringExtra(MainActivity.WEIGHT_KEY) + " (" + result.getData().getStringExtra(MainActivity.GENDER_KEY) + ")");
                    viewDrinkButton.setEnabled(true);
                    addDrinkButton.setEnabled(true);
                    drinks.clear();
                    Log.d("Size","Drinks Size: " + drinks.size());
                    numberOfDrinksText.setText(String.valueOf(drinks.size()));
                }
            }
        }
    });

    ActivityResultLauncher <Intent> startForResult2 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            if (result != null && result.getResultCode() == RESULT_OK) {
                Log.d("Result","Drink will make it through - 1");
                if (result.getData() != null && result.getData().getExtras() != null && result.getData().getSerializableExtra(AddDrink.DRINK_KEY) != null) {
                    Log.d("Result","Drink will make it through");
                    Drink drink1 = (Drink) result.getData().getSerializableExtra(AddDrink.DRINK_KEY);
                    Log.d("Result","Drink Size in main class: " + drink1.drinkSize);
                    Log.d("Result","Drink Level in main class: " + drink1.alcoholLevel);
                    drinks.add(drink1);
                    numberOfDrinksText.setText(String.valueOf(drinks.size()));
                }
            }
        }
    });

    ActivityResultLauncher <Intent> startForResult3 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {

        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weightButton = findViewById(R.id.setWeightButton);
        weightText = findViewById(R.id.setWeightTextView);
        drinkText = findViewById(R.id.numberOfDrinksTextView);
        viewDrinkButton = findViewById(R.id.viewDrinksButton);
        addDrinkButton = findViewById(R.id.addDrinkButton);
        viewDrinkButton.setEnabled(false);
        addDrinkButton.setEnabled(false);
        numberOfDrinksText = findViewById(R.id.numberOfDrinksTextView);
        resetButton = findViewById(R.id.resetButton3);

        weightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,activity2.class);
                startForResult.launch(intent);
            }
        });
//        if (getIntent() != null && getIntent().getExtras() != null &&
//                getIntent().hasExtra(MainActivity.GENDER_KEY) && getIntent().hasExtra(MainActivity.WEIGHT_KEY)) {
//                weightText.setText(getIntent().getStringExtra(MainActivity.WEIGHT_KEY) + " (" + getIntent().getStringExtra(MainActivity.GENDER_KEY) + ")");
//        }
        viewDrinkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (drinks.size() == 0) {
                Log.d("ViewDrink","This shit didnt work :(");
                Toast.makeText(getApplicationContext(),"No Drinks In List",Toast.LENGTH_SHORT).show();
                 } else {
                    Intent intent = new Intent(getApplicationContext(), ViewDrinks.class);
                    intent.putExtra(DRINK_LIST,drinks);
                    startActivity(intent);
                }
            }
        });

        addDrinkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,AddDrink.class);
                startForResult2.launch(intent);
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                weightText.setText("N/A");
                resetButton.setEnabled(false);
                addDrinkButton.setEnabled(false);
                drinks.clear();
                numberOfDrinksText.setText(String.valueOf(0));
            }
        });






//        if (getIntent() != null && getIntent().getExtras() != null &&
//                getIntent().hasExtra(MainActivity.GENDER_KEY) && getIntent().hasExtra(MainActivity.WEIGHT_KEY)
//        && getIntent().getSerializableExtra("DRINK_KEY") == null) {
//            Log.d("UserInformation","Drink made it in");
//            Log.d("UserInformation" , "Intent:" + getIntent().getSerializableExtra("DRINK_KEY"));
//            Drink drink = (Drink) getIntent().getSerializableExtra(DRINK_KEY);
//            Log.d("UserInformation","Alcohol Level: " + drink.alcoholLevel);
//        }


    }

}